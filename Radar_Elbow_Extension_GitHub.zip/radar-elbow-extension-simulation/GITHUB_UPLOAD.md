# Upload the radar simulation

The repository for this project is [DhanishRam/radar-elbow-extension-simulation](https://github.com/DhanishRam/radar-elbow-extension-simulation).

1. Extract the project ZIP and open the folder containing `README.md`.
2. Open the repository. For an empty repository, choose **uploading an existing file** under **Quick setup**. For a repository containing files, choose **Add file → Upload files**.
3. Drag the contents of the extracted folder into the upload area. Include `src/`, `config/`, `docs/`, `tests/`, `examples/`, `README.md`, `requirements.txt`, `GITHUB_UPLOAD.md` and `.gitignore`. On a Mac, press **Command + Shift + .** in Finder to show `.gitignore`.
4. Review the files. The list should include `src/simulate.py` and `docs/figures/delivery.png`. The README belongs at the top level.
5. Use the commit message `Update radar simulation, reproducible examples and documentation`. Click **Commit changes**.
6. Open the **Code** tab and scroll to the README. Check that the delivery plot appears and that the reference results link opens.

**Suggested description**

Python simulation of a coded FMCW radar sleeve that estimates elbow extension during a cricket delivery, with reflected radar views and blind decoding of overlapping echoes.

**Suggested topics**

`python` · `numpy` · `radar` · `fmcw` · `signal-processing` · `biomechanics`

[GitHub upload documentation](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)
