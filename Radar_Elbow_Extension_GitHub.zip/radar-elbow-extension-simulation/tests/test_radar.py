"""Regression tests for coded returns and elbow reconstruction."""

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

from simulate import align, codebook, fit_rate, run
from collision import experiment


class RadarTests(unittest.TestCase):

    def setUp(self):
        self.cfg = json.loads((ROOT / 'config/demo.json').read_text())

    def test_rank_deficient(self):
        self.assertIsNone(fit_rate(np.ones((12, 8)), np.ones(12), np.ones(12), 150))

    def test_rigid_pose(self):
        points = np.eye(3)
        rot = np.array([[0, -1, 0], [1, 0, 0], [0, 0, 1]])
        recovered, origin = align(points, points @ rot.T + [2, 1, 3])
        np.testing.assert_allclose(recovered, rot, atol=1e-12)
        np.testing.assert_allclose(origin, [2, 1, 3])

    def test_blind_collision(self):
        r = experiment(codebook(16, 512), self.cfg)
        found = {row['id']: row for row in r['decoded']}
        self.assertEqual(set(found), {0, 15, 16})
        for row in r['truth']:
            self.assertAlmostEqual(found[row['id']]['speed_m_s'], row['speed_m_s'], delta=0.1)

    def test_extension_and_hyperextension(self):
        with tempfile.TemporaryDirectory() as td:
            for angles, expected in [([30, 33, 8], 25), ([6, 6, -12], 6), ([15, 15, 15], 0)]:
                with self.subTest(angles=angles):
                    r = run({**self.cfg, 'flexion_deg': angles}, Path(td))
                    self.assertAlmostEqual(r['true_extension_deg'], expected)
                    self.assertAlmostEqual(r['estimated_extension_deg'], expected, delta=1.0)

    def test_dropout_withholds_result(self):
        with tempfile.TemporaryDirectory() as td:
            r = run({**self.cfg, 'dropout': 1}, Path(td))
        self.assertIsNone(r['estimated_extension_deg'])

    def test_cli_seed_override_matches_config(self):
        """An explicit seed must match editing that field in a copied config."""
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            cfg = dict(self.cfg, seed=43)
            custom_config = root / "custom.json"
            custom_config.write_text(json.dumps(cfg), encoding="utf-8")
            script = str(ROOT / "src/simulate.py")
            for name, args in [
                ("override", ["--seed", "43"]),
                ("configured", ["--config", str(custom_config)]),
            ]:
                subprocess.run(
                    [sys.executable, script, *args, "--out", str(root / name)],
                    check=True, capture_output=True,
                )
            report = (root / "override/summary.json").read_bytes()
            self.assertEqual(report, (root / "configured/summary.json").read_bytes())
            self.assertNotEqual(
                json.loads(report),
                json.loads((ROOT / "examples/reference_summary.json").read_text()),
            )
