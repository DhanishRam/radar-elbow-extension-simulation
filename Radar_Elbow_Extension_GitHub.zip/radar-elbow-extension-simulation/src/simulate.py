"""Coded sleeve FMCW measurement of elbow extension. Distances in metres and reported angles in degrees."""

import argparse
import csv
import itertools
import json
import math
from pathlib import Path

import numpy as np

from collision import experiment

ROOT = Path(__file__).resolve().parents[1]
C = 299792458.0


def rotate(axis, angle):
    """Return a right-handed rotation matrix for axis 0, 1 or 2, in radians."""
    c, s = (np.cos(angle), np.sin(angle))
    i, j = ((axis + 1) % 3, (axis + 2) % 3)
    mat = np.eye(3)
    mat[i, i] = mat[j, j] = c
    mat[i, j], mat[j, i] = (-s, s)
    return mat


def layout(n):
    """Place markers in a spiral around each segment. Lengths are in metres."""
    i = np.arange(n)
    a = i * np.pi * (3 - np.sqrt(5))
    normals = np.column_stack((0 * i, np.cos(a), np.sin(a)))
    arms = 0.033 * normals
    arms[:, 0] = np.linspace(0.055, 0.26, n)
    upper = arms.copy()
    upper[:, 0] *= -1
    return (upper, arms, normals)


def pose(u, cfg, markers):
    """u runs from the specified horizontal frame to the release frame."""
    upper, lower, normals = markers
    start, peak, end = cfg['flexion_deg']
    split = 0.25
    a, b, v = (start, peak, u / split) if u < split else (peak, end, (u - split) / (1 - split))
    flex = a + (b - a) * (1 - np.cos(np.pi * v)) / 2
    rad = np.deg2rad
    ru = rotate(1, -1.45 * u) @ rotate(0, rad(cfg['humeral_twist_deg']) * u)
    pre = ru @ rotate(2, rad(flex)) @ rotate(1, rad(cfg['carrying_angle_deg']))
    rf = pre @ rotate(0, rad(cfg['pronation_deg']) * u)
    joint = np.array([0.2 * u, 0.03 * u, 1.55]) + ru[:, 0] * 0.28
    arms = np.vstack((upper @ ru.T, lower @ rf.T))
    return (joint + arms, np.vstack((normals @ ru.T, normals @ rf.T)), joint, ru[:, 2], rf[:, 0], flex)


def align(template, measured):
    """Fit a proper rotation and translation to corresponding 3D marker positions."""
    centered = template - template.mean(0)
    left, _, right = np.linalg.svd(centered.T @ (measured - measured.mean(0)))
    signs = np.diag([1.0, 1.0, np.linalg.det(left @ right)])
    rotation = (left @ signs @ right).T
    origin = measured.mean(0) - rotation @ template.mean(0)
    return (rotation, origin)


def codebook(n, samples):
    """Generate six-notch envelopes with at most three shared slots per pair."""
    options = list(itertools.combinations(range(16), 6))
    np.random.default_rng(104).shuffle(options)
    slots = []
    for choice in options:
        if all(len(set(choice).intersection(other)) <= 3 for other in slots):
            slots.append(choice)
            if len(slots) == n:
                break
    if len(slots) < n:
        raise ValueError('too many sleeve markers for this codebook')
    f = np.arange(samples) / samples * 4
    centers = np.linspace(0.25, 3.75, 16)
    envelopes = []
    for row in slots:
        offset = (f[:, None] - centers[list(row)]) / 0.1
        envelopes.append(1 - 0.9 * np.sum(1 / (1 + offset**2), axis=1))
    return np.array(envelopes)


def paths(pos, normals, cfg, rng):
    """Yield visible markers, sight directions, ranges and amplitudes per view."""
    real = np.array(cfg['radar_m'])
    for panel in [None, *cfg['panels']]:
        image = real.copy()
        if panel:
            axis, plane = (panel['axis'], panel['plane_m'])
            image[axis] = 2 * plane - real[axis]
        delta = pos - image
        ranges = np.linalg.norm(delta, axis=1)
        dirs = delta / ranges[:, None]
        cosines = -np.sum(normals * dirs, axis=1)
        visible = cosines > np.cos(np.deg2rad(cfg['field_of_view_deg']))
        if panel:
            transverse = [i for i in range(3) if i != axis]
            t = (plane - image[axis]) / delta[:, axis]
            hit = image + t[:, None] * delta
            margin = np.sqrt(C / cfg['carrier_hz'] * ranges * np.maximum(0, t * (1 - t)))
            offset = np.abs((hit - panel['center_m'])[:, transverse])
            fits_panel = np.all(offset + margin[:, None] < panel['halfwidths_m'], axis=1)
            visible &= (t > 0) & (t < 1) & fits_panel
        ids = np.flatnonzero(visible & (rng.random(len(pos)) >= cfg['dropout']))
        yield (image, ids, dirs, ranges, np.maximum(0, cosines) * (4 / ranges) ** 2 * (0.7 if panel else 1))


def observe(r, v, amp, codes, predicted_r, cfg, rng):
    """A single beamformed view; coherent mixtures share fast-time samples."""
    bandwidth, carrier = (cfg['bandwidth_hz'], cfg['carrier_hz'])
    k = np.arange(cfg['chirps']) - (cfg['chirps'] - 1) / 2
    slow = k * cfg['chirp_period_s']
    fast = np.arange(cfg['samples']) / cfg['samples'] - 0.5
    # Complex IF occupies [0, fs). Check maximum equivalent range before sampling.
    if np.max(r + abs(slow).max() * np.abs(v)) * 2 * bandwidth / C >= cfg['samples']:
        raise ValueError('range aliases: increase samples')
    if np.any(abs(v) >= C / (4 * carrier * cfg['chirp_period_s'])):
        raise ValueError('Doppler aliases: shorten chirp_period_s')
    ranges = r[None, :] + slow[:, None] * v
    phase = rng.uniform(-np.pi, np.pi, len(r))
    slow_amp = amp * np.exp(1j * (phase + 4 * np.pi * carrier / C * slow[:, None] * v))
    atoms = codes[None, :, :] * np.exp(2j * np.pi * 2 * bandwidth / C * ranges[:, :, None] * fast)
    iq = np.einsum('ki,kij->kj', slow_amp, atoms)
    iq += cfg['noise_sd'] * (rng.normal(size=iq.shape) + 1j * rng.normal(size=iq.shape)) / np.sqrt(2)
    # Pose-aided dictionary; it receives predicted ranges and code assignments only.
    dictionary = codes * np.exp(2j * np.pi * 2 * bandwidth / C * predicted_r[:, None] * fast)
    coeff = np.linalg.lstsq(dictionary.T, iq.T, rcond=1e-07)[0]
    corr = np.sum(coeff[:, 1:] * coeff[:, :-1].conj(), axis=1)
    # Intra-frame beat migration adds the code-energy-weighted fast-time phase.
    center = codes ** 2 @ fast / (codes ** 2).sum(axis=1)
    return np.angle(corr) * C / (4 * np.pi * (carrier + bandwidth * center) * cfg['chirp_period_s'])


def fit_rate(rows, speeds, weights, max_se):
    """Fit the eight joint-motion parameters and gate the flexion rate by precision."""
    if len(rows) <= 8:
        return None
    w = np.asarray(weights)
    a = np.asarray(rows) * w[:, None]
    y = np.asarray(speeds) * w
    x, _, rank, _ = np.linalg.lstsq(a, y, rcond=1e-07)
    if rank < 8:
        return None
    sigma = np.sqrt(np.sum((a @ x - y) ** 2) / (len(y) - 8))
    se = sigma * np.linalg.norm(np.linalg.pinv(a)[6])
    return (np.rad2deg(x[6]), np.rad2deg(se)) if np.rad2deg(se) <= max_se else None


def sample_frame(t, markers, codes, cfg, rng):
    """Synthesize one frame and fit its flexion rate from the observed echoes."""
    u = t / cfg["duration_s"]
    n = cfg["markers_per_segment"]
    positions, normals, _, _, _, angle = pose(u, cfg, markers)
    before = pose(u - 1e-5, cfg, markers)[0]
    after = pose(u + 1e-5, cfg, markers)[0]
    velocity = (after - before) / (2e-5 * cfg["duration_s"])
    measured = positions + rng.normal(0, cfg["pose_sd_m"], positions.shape)

    upper, upper_origin = align(markers[0], measured[:n])
    forearm, forearm_origin = align(markers[1], measured[n:])
    joint = (upper_origin + forearm_origin) / 2
    flex_axis, twist_axis = upper[:, 2], forearm[:, 0]
    pose_angle = np.rad2deg(np.arctan2(twist_axis @ upper[:, 1], twist_axis @ upper[:, 0]))

    rows, speeds, weights = [], [], []
    for image, ids, dirs, ranges, amplitude in paths(positions, normals, cfg, rng):
        if not len(ids):
            continue
        relative = measured[ids] - image
        predicted_range = np.linalg.norm(relative, axis=1)
        sight = relative / predicted_range[:, None]
        lever = np.cross(measured[ids] - joint, sight)
        forearm_mask = ids >= n
        rows.extend(np.column_stack((
            sight, lever, (lever @ flex_axis) * forearm_mask,
            (lever @ twist_axis) * forearm_mask,
        )))
        speeds.extend(observe(
            ranges[ids], (dirs[ids] * velocity[ids]).sum(1), amplitude[ids],
            codes[ids], predicted_range, cfg, rng,
        ))
        weights.extend(amplitude[ids])

    fit = fit_rate(rows, speeds, weights, cfg["max_rate_se_deg_s"])
    rate, rate_se = fit or (np.nan, np.nan)
    return (t, angle, len(rows), rate, rate_se), pose_angle


def reconstruct(times, rates, pose_angles, cfg, rng):
    """Integrate supported Doppler rates and anchor the result to observed poses."""
    valid = np.isfinite(rates)
    supported = bool(
        valid[0] and valid[-1]
        and np.max(np.diff(times[valid]), initial=0) <= 0.0050001
    )
    if not supported:
        return np.full(len(times), np.nan), np.full(len(times), np.nan), False

    rates = np.interp(times, times[valid], rates[valid])
    initial = pose_angles[0] + rng.normal(0, cfg["seed_angle_sd_deg"])
    increments = (rates[1:] + rates[:-1]) * np.diff(times) / 2
    integrated = initial + np.r_[0, np.cumsum(increments)]

    pose_sd = cfg["fusion_pose_sd_deg"]
    increment_sd = cfg["fusion_increment_sd_deg"]
    identity = np.eye(len(times))
    design = np.vstack((identity / pose_sd, np.diff(identity, axis=0) / increment_sd))
    observations = np.r_[pose_angles / pose_sd, np.diff(integrated) / increment_sd]
    fused = np.linalg.lstsq(design, observations, rcond=None)[0]
    return integrated, fused, True


def extension(trace):
    """Return peak-to-release extension in degrees, discounting hyperextension."""
    return float(max(0, max(trace) - max(trace[-1], 0)))


def run(cfg, out):
    """Run a synthetic delivery, write its per-frame CSV and return the summary."""
    rng = np.random.default_rng(cfg["seed"])
    n, frames = cfg["markers_per_segment"], cfg["frames"]
    if n < 3 or frames < 5 or cfg["chirps"] < 2 or cfg["duration_s"] <= 0:
        raise ValueError("need >=3 markers, >=5 frames, >=2 chirps and positive duration")
    if not 0 <= cfg["dropout"] <= 1:
        raise ValueError("dropout must be a probability between 0 and 1")
    for key in ("fusion_pose_sd_deg", "fusion_increment_sd_deg"):
        if not math.isfinite(cfg[key]) or cfg[key] <= 0:
            raise ValueError(f"{key} must be finite and positive")

    markers, codes = layout(n), codebook(2 * n, cfg["samples"])
    times = np.linspace(0, cfg["duration_s"], frames)
    records, angles = [], []
    for t in times:
        record, angle = sample_frame(t, markers, codes, cfg, rng)
        records.append(record)
        angles.append(angle)
    rates = np.array([row[3] for row in records])
    integrated, fused, supported = reconstruct(times, rates, np.asarray(angles), cfg, rng)

    out.mkdir(parents=True, exist_ok=True)
    with (out / "frames.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "time_s", "truth_deg", "echoes", "rate_deg_s", "rate_se_deg_s",
            "rate_integral_deg", "pose_deg", "fused_deg",
        ])
        for record, integral, pose_angle, estimate in zip(records, integrated, angles, fused):
            row = (*record, integral, pose_angle, estimate)
            writer.writerow([value if np.isfinite(value) else "" for value in row])

    return {
        "collision": experiment(codes, cfg),
        "true_extension_deg": extension([row[1] for row in records]),
        "estimated_extension_deg": extension(fused) if supported else None,
        "rate_only_extension_deg": extension(integrated) if supported else None,
        "accepted_frames": int(np.isfinite(rates).sum()),
        "frames": frames,
        "status": "resolved" if supported else "insufficient_geometry",
    }


def main():
    """Run the command-line interface and report configuration or file errors."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=ROOT / "config/demo.json",
                        help="input JSON configuration (default: config/demo.json)")
    parser.add_argument("--out", type=Path, default=ROOT / "results",
                        help="directory for frames.csv and summary.json")
    parser.add_argument("--seed", type=int, help="override the configured random seed for this run")
    args = parser.parse_args()
    try:
        cfg = json.loads(args.config.read_text(encoding="utf-8"))
        if not isinstance(cfg, dict):
            raise ValueError("configuration must be a JSON object")
        if args.seed is not None:
            cfg["seed"] = args.seed
        summary = run(cfg, args.out)
        report = json.dumps(summary, indent=2, allow_nan=False)
        (args.out / "summary.json").write_text(report + "\n", encoding="utf-8")
    except KeyError as err:
        parser.error(f"missing configuration field {err}")
    except (ValueError, OSError) as err:
        parser.error(str(err))
    print(report)


if __name__ == "__main__":
    main()
