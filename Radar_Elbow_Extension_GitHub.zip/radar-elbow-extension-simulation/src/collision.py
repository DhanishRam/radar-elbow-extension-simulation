"""Blind decoding of overlapping sleeve-marker returns in one radar view."""

import numpy as np


def decode(iq, codes, oversample=4, max_atoms=4):
    """Return (marker ID, range cell, phase advance per chirp) for each detection.

    Rows of iq are successive chirps. Rows of codes contain the fast-time
    envelope for each available marker. The last dictionary row represents
    an uncoded reflector. Detection and refinement use no ground-truth IDs.
    """
    dictionary = np.vstack([codes, np.ones(codes.shape[1])])
    template_energy = (dictionary**2).sum(axis=1)
    samples = iq.shape[1]
    fast_time = np.arange(samples) / samples

    def fit(support):
        atoms = np.stack(
            [
                dictionary[code] * np.exp(2j * np.pi * beat * fast_time)
                for code, beat in support
            ],
            axis=1,
        )
        amplitudes = np.linalg.lstsq(atoms, iq.T, rcond=None)[0]
        error = iq - (atoms @ amplitudes).T
        return np.linalg.norm(error)**2, amplitudes, error

    residual = iq.copy()
    selected = []
    initial_energy = np.linalg.norm(iq)**2
    previous_energy = initial_energy
    for _ in range(max_atoms):
        best_score, identity, beat = -1, None, None
        for code, template in enumerate(dictionary):
            if any(existing == code for existing, _ in selected):
                continue
            spectrum = np.fft.fft(residual * template, samples * oversample, axis=1)
            score = (abs(spectrum)**2).sum(axis=0) / template_energy[code]
            index = np.argmax(score)
            if score[index] > best_score:
                best_score, identity, beat = score[index], code, index / oversample

        if identity is None:
            break
        trial = [*selected, (identity, beat)]
        energy, _, error = fit(trial)
        # Refine the selected beat frequencies while fitting all amplitudes jointly.
        for step in (0.125, 0.0625, 0.03125):
            for i in range(len(trial)):
                code, center = trial[i]
                for shift in (-step, step):
                    alternative = trial.copy()
                    alternative[i] = (code, center + shift)
                    candidate_energy, _, candidate_error = fit(alternative)
                    if candidate_energy < energy:
                        trial, energy, error = alternative, candidate_energy, candidate_error

        if previous_energy - energy < 0.001 * initial_energy:
            break
        previous_energy, selected, residual = energy, trial, error

    if not selected:
        return []
    _, amplitudes, _ = fit(selected)
    return [
        (int(code), float(beat), float(np.angle(np.vdot(a[:-1], a[1:]))))
        for (code, beat), a in zip(selected, amplitudes)
    ]


def experiment(codes, cfg):
    """Generate a known collision and score the independently decoded returns."""
    rng = np.random.default_rng(cfg["seed"] + 9)
    samples, chirps = codes.shape[1], cfg["chirps"]
    fast_time = np.arange(samples) / samples
    wavelength = 299792458 / cfg["carrier_hz"]
    chirp_period = cfg["chirp_period_s"]
    uncoded_id = len(codes)
    # Each tuple holds ID, range in cells, radial speed in m/s and amplitude.
    truths = [
        (0, 66.25, 1.8, 1.0),
        (uncoded_id - 1, 66.50, -2.4, 0.82),
        (uncoded_id, 69.0, 0.3, 0.18),
    ]
    templates = np.vstack((codes, np.ones(samples)))
    iq = np.zeros((chirps, samples), complex)
    for identity, beat, speed, amplitude in truths:
        phase = 4 * np.pi * speed / wavelength * np.arange(chirps) * chirp_period
        iq += (
            amplitude * np.exp(1j * phase[:, None]) * templates[identity]
            * np.exp(2j * np.pi * beat * fast_time)
        )
    noise = rng.normal(size=iq.shape) + 1j * rng.normal(size=iq.shape)
    iq += cfg["noise_sd"] * noise / np.sqrt(2)
    return {
        "truth": [
            {"id": i, "range_cell": beat, "speed_m_s": speed}
            for i, beat, speed, _ in truths
        ],
        "decoded": [
            {
                "id": i,
                "range_cell": beat,
                "speed_m_s": phase * wavelength / (4 * np.pi * chirp_period),
            }
            for i, beat, phase in decode(iq, codes)
        ],
        "uncoded_id": uncoded_id,
    }
