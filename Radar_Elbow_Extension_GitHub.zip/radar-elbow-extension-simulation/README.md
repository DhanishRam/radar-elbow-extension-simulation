# Measuring elbow extension with a coded radar sleeve

Can a radar distinguish elbow extension from the rotation of the whole arm during a cricket delivery? This Python simulation models a sleeve with eight passive markers on the upper arm and eight on the forearm. It combines their radar echoes with noisy marker positions to estimate how far the elbow straightens between peak flexion and release.

## One simulated delivery

The elbow starts at 30° of flexion, reaches 33° and releases at 8°. That gives a known extension of **25.00°**. With the default seed, the estimator recovers **24.89°** over an 80 ms delivery window.

| Reconstruction | Estimated extension | Absolute error |
| --- | ---: | ---: |
| Integrate the radar-derived flexion rate | 24.64° | 0.36° |
| Combine that rate with marker pose | 24.89° | 0.11° |

![Simulated and reconstructed flexion over 80 milliseconds, with the signed error shown underneath](docs/figures/delivery.png)

The lower panel shows reconstructed flexion minus simulated flexion for all 81 frames. A positive error means the reconstructed elbow was more bent at that instant. [Reference results](examples/reference_summary.json)

## Run it locally

From the repository root on macOS or Linux, run the following commands with Python 3.12. NumPy is the only runtime dependency.

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python src/simulate.py
```

Open `results/summary.json` for the extension estimate and the marker decoding results. Open `results/frames.csv` to inspect each frame's echo count, estimated flexion rate and reconstructed angle.

## How it works

1. **Generate the echoes.** Each sleeve marker has a distinct frequency-notch pattern. A frequency-modulated continuous-wave (FMCW) radar receives direct echoes and reflections from two flat panels, giving different views of the moving arm.
2. **Estimate joint motion.** Noisy marker positions supply the arm geometry. Phase changes between radar chirps give radial speeds. A joint motion fit uses both segments to distinguish elbow flexion from forearm pronation and upper-arm rotation.
3. **Calculate extension.** Combine the fitted flexion rates with the marker pose angles, then measure the drop from peak flexion to release. If the elbow passes through straight, only the motion up to straight counts toward extension.

A separate blind decoding experiment places two coded markers one quarter of a range cell apart. Given their mixed signal and the codebook, the decoder recovers both marker identities and their opposite directions of travel. [Decoder implementation](src/collision.py)

## Repeat an experiment

The default seed is 42. To generate another realization of the same delivery, run the same configuration with another seed and a separate output directory.

```bash
python src/simulate.py --seed 43 --out results/seed_43
```

## Try a different delivery

Copy [the example configuration](config/demo.json) and change `flexion_deg`. Its three entries are **initial, peak and release flexion**, in degrees. For example, `[6, 6, -12]` gives 6° of extension followed by 12° of hyperextension.

```bash
cp config/demo.json config/my_delivery.json
# Edit config/my_delivery.json, then run:
python src/simulate.py --config config/my_delivery.json --out results/my_delivery
```

To test signal loss, set `dropout` to `1`. With every echo removed, the expected status is `insufficient_geometry` and the extension estimate is `null`. The [regression tests](tests/test_radar.py) cover rigid pose recovery, overlapping echoes, hyperextension and an underdetermined motion fit.

```bash
python -m unittest discover -s tests -v
```

## Scope of the result

The 0.11° error belongs to one synthetic delivery. The reconstruction receives labelled marker positions, calibrated reflector geometry and the start and release times. The default run uses 80° marker visibility and enlarged reflectors. Accuracy on a physical sleeve remains unmeasured. [Measurement model and assumptions](docs/MODEL.md)


## Contributing

Use an issue to describe the delivery or failure case you want to reproduce. Include the configuration, seed, Python and NumPy versions, and the relevant fields from `summary.json`. For a code change, run the tests above and describe how the change affects the default result or the failure case in your pull request.

## Project origin

This repository builds on the supplied coded-sleeve radar elbow-extension simulation and its measurement model. The source was written for this project. All observations are synthetic. The reference JSON records the original seeded run. [Model documentation](docs/MODEL.md) · [GitHub upload instructions](GITHUB_UPLOAD.md)
