# Measurement model

1. Generate upper-arm and forearm rigid motion with humeral twist, a flexion peak at one quarter of the window, carrying angle, pronation and joint translation. Sixteen marker normals and positions follow their segments. Finite differences supply ground-truth velocity to the signal generator.
2. Reflect the radar across the ground and side planes to find two virtual viewing positions. Intersect each reflected line of sight with its panel. Enforce finite aperture, first Fresnel margin, element visibility and random dropouts. Amplitude scales with incidence and inverse squared range.
3. Mix each visible marker's notch envelope, range beat and inter-chirp Doppler phase into complex samples. Include constant-velocity range migration and white receiver noise. Center fast time at mid-band. With normalized fast time, beat cycles across the sweep equal 2BR/c. The ramp duration gives the corresponding beat frequency in Hz. Complex sampling here uses a one-sided beat grid.
4. For the delivery reconstruction, simulate a separate calibrated position observation for each labelled marker. Align each segment's known layout to the noisy positions by rigid least squares. Predict ranges from the observed positions and demix the coded returns in each view by least squares. Recover radial speed from successive chirp phases. Geometry quality includes the rank and estimated standard error of the flexion rate.
5. For each echo, the linear measurement row contains the sight direction, lever-arm cross sight direction, and forearm-only projections of that cross product on flexion and pronation axes. The eight unknowns are three joint translation rates, three upper-arm rotation rates, flexion rate and pronation rate. Amplitude weights approximate relative measurement precision.
6. Integrate accepted rates, allowing interior interpolation across supported intervals up to 5 ms. Require accepted endpoints. A second fit combines rate increments and independent noisy pose angles using fixed demo weights. Extension equals the peak flexion less the positive part of release flexion, with a zero lower bound. This discounts hyperextension.
7. Independently exercise blind identification when two coded tags share one range cell with an uncoded return nearby. Search over code and beat frequency, subtract the joint least-squares fit, and refine selected frequencies. Compare against synthetic identities and radial speeds only after decoding.

## Assumptions and interpretation

The window endpoints, panel survey, per-view candidate lists and noisy labelled positions are supplied to the delivery reconstruction. The separate collision experiment starts with unlabelled mixed samples. Full-array beamforming, anatomical calibration from a real sleeve, autonomous ball-release detection, clothing clutter statistics and official adjudication are outside this implementation. The reported rate standard error is a within-frame fit diagnostic.

The seeded demonstration uses 80° tag visibility and larger panels than the nominal embodiment to sustain observations through release. Set `field_of_view_deg` to 65 to try the disclosed nominal angle. This change can leave too few valid frames and produce a null extension. The fixture uses 512 fast-time samples, 12 chirps, a 4 GHz sweep and 25 µs chirp repetition. Relative amplitudes and noise are synthetic. Each marker carries six notches drawn from 16 frequency slots with at most three shared between codes.

| Input group | Units or meaning |
| --- | --- |
| `flexion_deg` | Initial, peak and release angle |
| `radar_m`, panel geometry | Cartesian metres. Panel half-widths follow the two remaining axes in ascending axis order |
| `pose_sd_m`, `noise_sd`, `dropout` | Position standard deviation, complex RMS receiver noise in relative units, independent probability per visible echo |
| `fusion_pose_sd_deg`, `fusion_increment_sd_deg` | Pose and integration-increment weights in the final fit |
| `max_rate_se_deg_s` | Frame rejection threshold |
